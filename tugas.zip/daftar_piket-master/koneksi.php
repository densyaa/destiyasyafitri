<?php 
	$koneksi = new mysqli("localhost","root","","daftar_piket");
 ?>